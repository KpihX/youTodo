import tache from 'app/entities/tache/tache.reducer';
import categorie from 'app/entities/categorie/categorie.reducer';
/* jhipster-needle-add-reducer-import - JHipster will add reducer here */

const entitiesReducers = {
  tache,
  categorie,
  /* jhipster-needle-add-reducer-combine - JHipster will add reducer here */
};

export default entitiesReducers;
