export enum StatutTache {
  OUVERT = 'OUVERT',

  EN_COURS = 'EN_COURS',

  TERMINE = 'TERMINE',
}
