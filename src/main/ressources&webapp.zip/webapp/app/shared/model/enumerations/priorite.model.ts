export enum Priorite {
  BASSE = 'BASSE',

  MOYENNE = 'MOYENNE',

  HAUTE = 'HAUTE',
}
